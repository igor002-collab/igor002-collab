const express = require('express');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping recebido às ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT); // Recebe solicitações que o deixa online

const Discord = require("discord.js"); //Conexão com a livraria Discord.js
const client = new Discord.Client(); //Criação de um novo Client
const config = require("./config.json"); //Pegando o prefixo do bot para respostas de comandos

const prefixo = "c."



client.on("message", msg => {
  console.log("Breakpoint 1")
  if (msg.content == prefixo + "Teste") {
    msg.channel.send("oi!")
    console.log("Breakpoint 2")

  } else if (msg.content == prefixo + "mcskin") {
    console.log("Breakpoint 3")
    if (!args[0]) {
      const EmbedErro = new Discord.RichEmbed()
        .setColor("ff0000")
        .setDescription("Insira também o nome de usuário do Minecraft que deseja procurar.\n\nExemplo:\n" + prefixo + "mcskin zPedroo_")
      msg.channel.send(EmbedErro)
        ;
    }
    const request = require('request');
    request("https://minotar.net/armor/body/" + args[0] + "/128", function(error, response, body) {
      if (body == "404 not found") {
        const EmbedErro = new Discord.RichEmbed()
          .setColor("ff0000")
          .setDescription("Usuário não encontrado.")
        msg.channel.send(EmbedErro)
        return;
      } else {
        msg.channel.send("Skin de " + args[0] + "", { files: ["https://minotar.net/helm/" + args[0] + "/128.png", "https://minotar.net/armor/body/" + args[0] + "/100.png"] })
      }
    });
  }
})

// o




client.login(config.token)